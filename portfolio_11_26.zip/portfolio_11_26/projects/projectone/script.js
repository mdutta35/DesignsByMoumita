$(document).ready(function() {
    const applyModal = new bootstrap.Modal($('#applyModal')[0]);
    const enquireModal = new bootstrap.Modal($('#enquireModal')[0]);

    // Apply Button Trigger
    $('#openApply, .btn-apply').on('click', function() {
        // jQuery Fade In effect
        $('#applyModal .modal-content').hide().fadeIn(500);
        applyModal.show();
    });

    // Enquire Button Trigger
    $('#openEnquire, .btn-enquire').on('click', function() {
        // jQuery Fade In effect
        $('#enquireModal .modal-content').hide().fadeIn(500);
        enquireModal.show();
    });

    // Form Submissions
    $('#applyForm, #enquireForm').on('submit', function(e) {
        e.preventDefault();
        const $btn = $(this).find('button[type="submit"]');
        
        $btn.text('Processing...').prop('disabled', true);

        setTimeout(() => {
            alert('Success! Your details have been submitted.');
            applyModal.hide();
            enquireModal.hide();
            $btn.text('Submit').prop('disabled', false);
            this.reset();
        }, 1500);
    });
});




/*************************
 online-programs 
 ***********************/

 document.querySelectorAll('.filter-btn').forEach(button => {
    button.addEventListener('click', () => {
        // Switch active class
        document.querySelector('.filter-btn.active').classList.remove('active');
        button.classList.add('active');
        
        const filterValue = button.getAttribute('data-filter');
        const items = document.querySelectorAll('.course-card-item');

        items.forEach(item => {
            if (filterValue === 'all' || item.classList.contains(filterValue)) {
                item.style.display = 'block';
            } else {
                item.style.display = 'none';
            }
        });
    });
});





