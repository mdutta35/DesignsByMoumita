// eligibility-section-criteria-container dropdown

function toggleEligibility(contentId, iconId) {
    const content = document.getElementById(contentId);
    const icon = document.getElementById(iconId);

    // Toggle the 'd-none' class
    if (content.classList.contains('d-none')) {
        content.classList.remove('d-none');
        // Change icon to 'down'
        icon.classList.remove('bi-chevron-right');
        icon.classList.add('bi-chevron-down');
    } else {
        content.classList.add('d-none');
        // Change icon to 'right'
        icon.classList.remove('bi-chevron-down');
        icon.classList.add('bi-chevron-right');
    }
}



$(document).ready(function () {

    $('.accordion-collapse').on('show.bs.collapse', function () {
        $(this)
            .prev('.accordion-header')
            .find('.programs-offered-btn')
            .stop(true, true)
            .slideUp(300);
    });

    $('.accordion-collapse').on('hide.bs.collapse', function () {
        $(this)
            .prev('.accordion-header')
            .find('.programs-offered-btn')
            .stop(true, true)
            .slideDown(300);
    });

});