// navbar scrolling

let lastScrollY = window.scrollY;
const navbar = document.querySelector('.navbar');

window.addEventListener('scroll', () => {
    // 1. Vanishing Logic
    if (lastScrollY < window.scrollY && window.scrollY > 150) {
        navbar.classList.add('nav-hidden');
    } else {
        navbar.classList.remove('nav-hidden');
    }

    // 2. Background/Blur Logic
    if (window.scrollY > 50) {
        navbar.classList.add('scrolled');
    } else {
        navbar.classList.remove('scrolled');
    }

    lastScrollY = window.scrollY;
});



// all department design

document.addEventListener('DOMContentLoaded', function() {
    const filterButtons = document.querySelectorAll('.filter-btn');
    const cards = document.querySelectorAll('.program-card-wrapper');

    filterButtons.forEach(button => {
        button.addEventListener('click', () => {
            // 1. Update Active Button
            filterButtons.forEach(btn => btn.classList.remove('active'));
            button.classList.add('active');

            const filterValue = button.getAttribute('data-filter');

            // 2. Filter Logic
            cards.forEach(card => {
                const category = card.getAttribute('data-category');
                
                if (filterValue === 'all' || category === filterValue) {
                    // Show item
                    card.style.display = 'block';
                    setTimeout(() => {
                        card.style.opacity = '1';
                        card.style.transform = 'scale(1)';
                    }, 10);
                } else {
                    // Hide item
                    card.style.opacity = '0';
                    card.style.transform = 'scale(0.9)';
                    setTimeout(() => {
                        card.style.display = 'none';
                    }, 400); // Matches CSS transition time
                }
            });
        });
    });
});



// Slider-testimonial

const testimonials = [
    {
        name: "Ana Pirtskhalashvili",
        faculty: "Faculty of Social Sciences",
        text: "Ana is a graduate of the Georgian National University ABC. At 24, she won a scholarship to Sorbonne University and now works as an officer for European Affairs in Paris.",
        image: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?q=80&w=600"
    },
    {
        name: "Luka Beridze",
        faculty: "Business & Technology",
        text: "After graduating ABC with honors, Luka founded a tech startup in Berlin. He credits the university's practical workshops for his entrepreneurial success.",
        image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=600"
    },
    {
        name: "Mariam Kokoeva",
        faculty: "School of Law",
        text: "Mariam is now a leading human rights lawyer. Her journey from the lecture halls of ABC to the international courts has been truly inspiring.",
        image: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?q=80&w=800&auto=format&fit=crop"
    }
];

let currentIndex = 0;

function updateSlide(index) {
    const t = testimonials[index];
    
    // Add animation classes
    const content = document.querySelector('.testimonial-content');
    const img = document.getElementById('t-image');
    
    content.classList.remove('fade-up-content');
    img.style.opacity = '0';
    
    setTimeout(() => {
        // Update Text
        document.getElementById('t-name').innerText = t.name;
        document.getElementById('t-faculty').innerText = t.faculty;
        document.getElementById('t-text').innerText = `"${t.text}"`;
        document.getElementById('current-slide').innerText = `0${index + 1}`;
        
        // Update Image
        img.src = t.image;
        img.style.opacity = '1';
        
        // Re-trigger animation
        content.classList.add('fade-up-content');
    }, 300);
}

function nextSlide() {
    currentIndex = (currentIndex + 1) % testimonials.length;
    updateSlide(currentIndex);
}

function prevSlide() {
    currentIndex = (currentIndex - 1 + testimonials.length) % testimonials.length;
    updateSlide(currentIndex);
}

// Initialize
document.getElementById('total-slides').innerText = `0${testimonials.length}`;



//Contact
document.getElementById('contactForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const btn = this.querySelector('button');
    const originalText = btn.innerText;

    btn.innerText = "SENDING...";
    btn.disabled = true;

    // Simulate Success
    setTimeout(() => {
        btn.style.background = "#28a745";
        btn.innerText = "SUCCESS!";
        this.reset();
        
        setTimeout(() => {
            btn.style.background = "#1a1a1a";
            btn.innerText = originalText;
            btn.disabled = false;
        }, 2000);
    }, 1200);
});